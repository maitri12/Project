//
//  Home.swift
//  TasteBuds
//
//  Created by MAC2 on 26/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField

class Home: UIViewController {

    @IBOutlet weak var pass: SkyFloatingLabelTextFieldWithIcon!
    override func viewDidLoad() {
        super.viewDidLoad()
        //add()
        let nav = navigationController
        nav?.isNavigationBarHidden = false
        let navbar = UINavigationBar(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 43.5))
        let navitem = UINavigationItem(title: "Taste Buds")
        let swipe = UIBarButtonItem(barButtonSystemItem: .camera, target: self, action: #selector(self.swipeAction))
        let btn = UIButton(type: UIButton.ButtonType.custom)
        btn.setImage(UIImage(named: "door.png"), for: .normal)
        btn.addTarget(self, action: #selector(self.btnAction), for: .touchUpInside)
        btn.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        let btnitem = UIBarButtonItem(customView: btn)
        navitem.rightBarButtonItem = swipe
        navitem.leftBarButtonItem = btnitem
        navbar.items = [navitem]
        
        
    }
    
    @objc func btnAction()
    {
        print("button")
    }
    
    @objc func swipeAction()
    {
        print("swipe")
    }
    
    /*func add()
    {
        pass.placeholder = "Pass"
        pass.selectedLineColor = UIColor.blue
        pass.selectedLineHeight = 1
        pass.selectedTitle = "password"
        pass.selectedTitleColor = UIColor.blue
        pass.isSecureTextEntry = true
        
        pass.iconType = .image
        pass.iconImage = UIImage(named: "showPass.png")
        
    }*/
}

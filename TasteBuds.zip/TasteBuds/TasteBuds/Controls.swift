
import UIKit
import SkyFloatingLabelTextField
import TransitionButton

class Controls: NSObject {

    func customtext(frame : CGRect, placeholder : String , selLineCol : UIColor , selLineHei : CGFloat , selTitle : String , selTitleCol : UIColor , secure : Bool) -> SkyFloatingLabelTextField
    {
        let txt = SkyFloatingLabelTextField(frame: frame)
        txt.placeholder = placeholder
        txt.selectedLineColor = selLineCol
        txt.selectedLineHeight = selLineHei
        txt.selectedTitle = selTitle
        txt.selectedTitleColor = selTitleCol
        txt.isSecureTextEntry = secure
        return txt
    }
    
    func custombutton(frame : CGRect , bgcolor : UIColor , title : String , radius : CGFloat , spicolor : UIColor) -> TransitionButton
    {
        let login = TransitionButton(frame: frame)
        login.backgroundColor = bgcolor
        login.setTitle(title, for: .normal)
        login.cornerRadius = radius
        login.spinnerColor = spicolor
        return login
    }
}
